const express = require('express');
const bcrypt = require('bcrypt-nodejs');

const app = express();
app.use(express.json());

// 데이터 베이스
const database = {
    users: [
        {
            id: '123',
            name: 'edon',
            email: '2donny@naver.com',
            password: 'wjddlems123',
            entries: 0,
            joined: new Date()
        },
        {
            id: '124',
            name: 'Jason',
            email: 'Jason@naver.com',
            password: 'bigpel99',
            entries: 0,
            joined: new Date()
        }
    ]
}

// 시작 페이지
app.get('/', (req, res) => {
    res.json(database.users);
})

// 로그인
app.post('/signIn', (req, res) => {
    const {password} = req.body;
    bcrypt.compare("ABCDEG", '$2a$10$2E//3rbAveD1SwEziYe4zukY.Tb9Z/5.DsXBXtVb9Kxd6qa5hjzzC', function(err, res) {
        console.log('first try', res);
    });
    bcrypt.compare("veggies", '$2a$10$Nn1QQ8qybtNA6g/dI6i15OtJPhf7Ar30ryeLuC57qCJnIRJfRO7o.', function(err, res) {
        console.log('second try', res);
    });
})

// 회원가입
app.post('/register', (req, res) => {
    const { email, password } = req.body;
    bcrypt.hash(password, null, null, function(err, hash) {
        console.log(hash);
        res.send(hash);
    });
    database.users.push( {
        id: '125',
        name: 'Park',
        email,
        password,
        entries: 0,
        joined: new Date()
    })
})

// 프로필 조회
app.get('/profile/:id', (req, res) => {
    const { id } = req.params;
    database.users.forEach(account => {
        if(account.id === id) {
            res.json(account);
        }
    })
    res.send('존재하지 않는 ID입니다.');
})

// image 실행횟수
app.put('/image', (req, res) => {
    const { id } = req.body;
    database.users.forEach(account => {
        if(account.id === id) {
            account.entries += 1;
            res.json(account);
        }
    })
        res.status('404').send('User not found');
})

app.listen(3000, () => {
    console.log('server is running on 3000');
})